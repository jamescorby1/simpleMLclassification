Coursework 1, Group 4

James Corby K2108442
Sriharsha Aryasomayajula K1945900
Praveen Shivananda Koppad K1942361
Muhammed Arbaz K2060732

There are 3 python files within this folder (excluding this one).
Each file matches up with the tasks in the coursework brief. 

Please ensure you have the following packages installed:
- Sklearn (pip install sklearn)
- Numpy (pip install numpy)
- Pandas (pip install pandas)
- Seaborn (pip install seaborn)
- matplotlib.pyplot (pip install matplotlib)

Part1.py = Loading and analysis of the wine dataset. 

Part2.py = Clustering Machine Learning using Birch and kmeans. 

Part3.py = Classification Machine Learning using Guassian Bayes and Random Forest Classifier. 
